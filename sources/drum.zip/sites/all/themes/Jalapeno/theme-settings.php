<?php

include_once(drupal_get_path('theme', 'jalapeno') . '/inc/theme.settings.inc');
