
-- SUMMARY --

The Drupal Remember me module adds a "Remember me" checkbox to login forms.

For a full description of the module, visit the project page:
  http://drupal.org/project/remember_me

To submit bug reports and feature suggestions, or to track changes:
  http://drupal.org/project/issues/remember_me


-- REQUIREMENTS --

None.


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.


-- CONFIGURATION --



-- CUSTOMIZATION --



-- TROUBLESHOOTING --



-- FAQ --



-- CONTACT --

Current maintainers:
* Nick Lombard - http://drupal.org/user/71563
