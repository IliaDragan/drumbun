
(function ($) {
  $(document).ready(function() {
    $('#edit-current-pass').attr('autocomplete', 'OFF').val('');
    $('#edit-pass-pass1').attr('autocomplete', 'OFF').val('');
    $('#edit-pass-pass2').attr('autocomplete', 'OFF').val('');
  });
})(jQuery);
