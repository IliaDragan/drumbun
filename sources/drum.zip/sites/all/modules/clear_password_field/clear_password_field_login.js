
(function ($) {
  $(document).ready(function() {
    $('#edit-name').attr('autocomplete', 'OFF').val('');
    $('#edit-pass').attr('autocomplete', 'OFF').val('');
  });
})(jQuery);
