// $Id: readme.txt,v 1.1.2.1 2008/09/14 18:31:41 aaron Exp $

THIS MODULE INTENTIONALLY LEFT BLANK.

NOTICE: video_cck has been replaced by emvideo. If you follow the upgrade instructions properly,
i.e., you disable your modules in d5 before upgrading to d6, you should have no problems.
